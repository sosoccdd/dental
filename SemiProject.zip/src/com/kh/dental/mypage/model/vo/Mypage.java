package com.kh.dental.mypage.model.vo;

public class Mypage {

}
