package com.kh.dental.mypage.model.service;

public class MypageService {

}
