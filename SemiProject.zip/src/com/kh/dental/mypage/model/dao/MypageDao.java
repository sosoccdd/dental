package com.kh.dental.mypage.model.dao;

public class MypageDao {

}
