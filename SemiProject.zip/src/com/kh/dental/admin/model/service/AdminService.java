package com.kh.dental.admin.model.service;

public class AdminService {

}
