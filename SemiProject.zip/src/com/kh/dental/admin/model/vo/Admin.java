package com.kh.dental.admin.model.vo;

public class Admin {

}
