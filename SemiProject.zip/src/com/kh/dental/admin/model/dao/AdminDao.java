package com.kh.dental.admin.model.dao;

public class AdminDao {

}
