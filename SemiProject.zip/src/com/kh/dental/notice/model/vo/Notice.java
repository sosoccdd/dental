package com.kh.dental.notice.model.vo;

public class Notice {

}
