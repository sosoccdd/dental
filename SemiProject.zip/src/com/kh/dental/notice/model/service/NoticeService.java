package com.kh.dental.notice.model.service;

public class NoticeService {

}
