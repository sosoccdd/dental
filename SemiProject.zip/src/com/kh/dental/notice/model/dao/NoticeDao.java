package com.kh.dental.notice.model.dao;

public class NoticeDao {

}
