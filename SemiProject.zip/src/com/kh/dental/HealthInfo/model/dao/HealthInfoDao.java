package com.kh.dental.HealthInfo.model.dao;

public class HealthInfoDao {

}
