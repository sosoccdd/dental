package com.kh.dental.HealthInfo.model.service;

public class HealthInfoService {

}
