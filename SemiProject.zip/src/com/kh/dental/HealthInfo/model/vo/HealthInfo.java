package com.kh.dental.HealthInfo.model.vo;

public class HealthInfo {

}
