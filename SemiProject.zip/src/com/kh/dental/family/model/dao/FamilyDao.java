package com.kh.dental.family.model.dao;

public class FamilyDao {

}
