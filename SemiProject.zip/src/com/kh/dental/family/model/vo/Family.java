package com.kh.dental.family.model.vo;

public class Family {

}
