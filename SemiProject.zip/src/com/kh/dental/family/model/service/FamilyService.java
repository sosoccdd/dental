package com.kh.dental.family.model.service;

public class FamilyService {

}
